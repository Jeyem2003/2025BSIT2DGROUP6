<?php require 'header.php'; ?>
<link rel="stylesheet" href="style.css">
    <main>

        <main>
            <div class="main-content">
               
                <div class="row">
                    <div class="left-box">
                        <a href="CardSelectionNets.php">
                        <img src="images/nets.png" alt="Placeholder Image 1" class="left-box-image"></a>
                    </div>
                    <div class="middle-box green">
                       
                        <p>With the NETS Prepaid Card, you can say goodbye to long queues and loose change. Simply tap your card on the fare reader when you board and alight from any public bus, MRT, or LRT in Singapore. It’s that easy! The correct fare is automatically deducted, making your daily commute smooth and hassle-free.Keeping your card topped up is a breeze! You can add value to your card at thousands of locations, including convenience stores, ATMs, and top-up kiosks. </p>
                    </div>
                </div>
                <div class="row">
                    <div class="left-box">
                        <a href="CardSelectionEzlink.php">
                        <img src="images/image.png" alt="Placeholder Image 2" class="left-box-image"></a>
                    </div>
                    <div class="middle-box green">
                      
                        <p>For years, the EZ-Link card has been your trusted companion for getting around. It's a "stored-value" card, meaning the money is on the card itself. You'd top it up with cash or a debit card, and the fare would be instantly displayed on the reader as you tapped in and out of the bus or MRT. It was simple and reliable, and you could use it for everything from transport to paying at some retail shops.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="left-box">
                        <a href="CardSelectionOrca.php">
                        <img src="images/orca.png" alt="Placeholder Image 3" class="left-box-image"></a>
                    </div>
                    <div class="middle-box green">
                       
                        <p>The ORCA card, which stands for One Regional Card for All, is a unified transit payment system used across the Puget Sound region of Washington State. It functions as a single fare card, eliminating the need for commuters to carry cash or multiple passes for different transit agencies. The card is accepted by major transit providers, including King County Metro, Sound Transit, Community Transit, Pierce Transit, and Washington State Ferries, making it a comprehensive solution for regional travel.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="left-box">
                        <a href="CardSelectionTAP.php">
                        <img src="images/chalo.png" alt="Placeholder Image 4" class="left-box-image"></a>
                    </div>
                    <div class="middle-box green">
                        
                        <p>The Chalo Card is a contactless, tap-to-pay smart card that acts as an e-wallet. Passengers can load a monetary balance onto the card and use it to pay for their bus tickets with a simple tap on the conductor's machine. This method eliminates the need for carrying cash and dealing with loose change, which can significantly speed up the boarding process. The balance on the card does not expire, providing long-term value for a one-time purchase.</p>
                    </div>
                </div>
            </div>

            <div class="ads-sidebar">
                <div class="ad-card bdo">
                    <div class="ad-logo">BDO</div>
                    <div class="ad-content">
                        <h3>Finding ways to reach you</h3>
                        <p>BDO ATM on wheels is might just be at a stop near you.</p>
                    </div>
                    <div class="ad-image bdo-image"></div>
                </div>

                <div class="ad-card transfer-ad">
                 <div class="slideshow-container">
                   <img class="slideshow-image fade" src="images/bdo add.jpg" alt="BDO Ad 1">
                   <img class="slideshow-image fade" src="images/bdo add 2.jpg" alt="BDO Ad 2" style="display: none;">
                   <img class="slideshow-image fade" src="images/bdo add 3.jpg" alt="BDO Ad 3" style="display: none;">
                 </div>
            </div>
        </main>
    </div>
    <script src="adslideshow.js"></script>
</body>
</html>


<?php require 'footer.php'; ?>