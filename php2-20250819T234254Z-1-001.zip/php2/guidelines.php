<?php include 'header2.php';?>
 <link rel="stylesheet" href="guidelines.css">

    <main class="grid-container">
        <!-- Menu & Information Card -->
        <div class="card">
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M3 13h18V11H3v2zm0-4h18V7H3v2zm0 8h18v-2H3v2z"/>
            </svg>
            <h2>Menu & Information</h2>
        </div>

        <!-- How it works? Card -->
        <div class="card">
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm0-4h-2V7h2v8z"/>
            </svg>
            <h2>How it works?</h2>
        </div>

        <!-- Getting started Card -->
        <div class="card">
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z"/>
            </svg>
            <h2>Getting started</h2>
        </div>

        <!-- Lost or Stolen card Procedure -->
        <div class="card">
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <!-- Document icon to represent "Procedure" -->
                <path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm-2 16H8v-2h4v2zm0-4H8v-2h4v2zm2-7V4.5L17.5 9H14c-.55 0-1-.45-1-1z"/>
            </svg>
            <h2>Lost or Stolen card Procedure</h2>
        </div>

        <!-- Top-up rules -->
        <div class="card">
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 16H6V5h12v14zM16 8h-2V6h-2v2h-2v2h2v2h2v-2h2V8zm-8 4H6v-2h2v2zm-2 2h2v2H6v-2zm12-4h-2v-2h2v2z"/>
            </svg>
            <h2>Top-up rules</h2>
        </div>

        <!-- Support / help info -->
        <div class="card">
            <svg class="icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V7h12v4z"/>
            </svg>
            <h2>Support / help info</h2>
        </div>
    </main>
</div>
<?php require 'footer.php'; ?>

</body>
</html>