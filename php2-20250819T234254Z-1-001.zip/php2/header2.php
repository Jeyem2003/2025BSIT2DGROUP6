<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tap & Go</title>
    <link rel="stylesheet" href="guidelines.css">
    
</head>
<body>

<div class="container">
    <header class="header">
        <div class="logo">
            <img src="/images/logo.png" alt="Tap & Go Logo" class="header-logo" style="width:90px; height:45px;">
           <h1 class="text-4xl" style="color: white;">TAP&GO</h1>
        </div>
        <div class="house-icon">
            <a href="index.php" target="_self">
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                </svg>
            </a>
        </div>
    </header>
   
</div>
</body>
</html>