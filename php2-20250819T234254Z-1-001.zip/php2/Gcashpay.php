<?php include 'header3.php';?>
<link rel="stylesheet" href="numpad.css">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCash Payment</title>
    <link rel="stylesheet" href="numpad.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</head>
<body>

  <div class="payment-container">
        <div class="main-content">
    <h2>Gcash</h2>
    <h3 class="sub-heading">ENTER MOBILE NUMBER</h3>
    <input type="text" id="mobileNumber" class="input-box" readonly>
    
    <div class="keypad">
        <div class="key" onclick="appendNumber(1)">1</div>
        <div class="key" onclick="appendNumber(2)">2</div>
        <div class="key" onclick="appendNumber(3)">3</div>
        <div class="key" onclick="appendNumber(4)">4</div>
        <div class="key" onclick="appendNumber(5)">5</div>
        <div class="key" onclick="appendNumber(6)">6</div>
        <div class="key" onclick="appendNumber(7)">7</div>
        <div class="key" onclick="appendNumber(8)">8</div>
        <div class="key" onclick="appendNumber(9)">9</div>
        <div class="key" onclick="appendSpecial('*')">*</div>
        <div class="key" onclick="appendNumber(0)">0</div>
        <div class="key" onclick="backspace()">X</div>
       </div>
    </div>
    
    <div class="buttons-container">
        <button class="proceed-btn" onclick="proceed()">Proceed</button>
    </div>
</div>

<script>
    function appendNumber(number) {
        const mobileInput = document.getElementById('mobileNumber');
        mobileInput.value += number;
    }

    function backspace() {
        const mobileInput = document.getElementById('mobileNumber');
        mobileInput.value = mobileInput.value.slice(0, -1);
    }

    function proceed() {
        const mobileInput = document.getElementById('mobileNumber').value;
        if (mobileInput.length > 0) {
            // Change "your_next_page.html" to the actual page you want to go to
            window.location.href = "Gcashamount.php";
        } else {
            alert('Please enter a mobile number.');
        }
    }
</script>

</body>
</html>
<?php require 'footer.php'; ?>