<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tap & Go</title>
    <link rel="stylesheet" href="header.css">
</head>
<body>

    <div class="container">
        <header>
            <div class="logo">
                <img src="/images/logo.png" alt="Tap & Go Logo" class="header-logo">
                <h1>TAP&GO</h1>
            </div>
            <div class="help-icon">
                <a href="guidelines.php">?</a>
            </div>
            
            
        </header>

       
