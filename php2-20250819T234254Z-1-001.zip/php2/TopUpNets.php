<?php include 'header2.php';?>
<link rel="stylesheet" href="CardSelection.css">
<div class="content-container">
    <h1>Card Options</h1>
    <div class="card-options-layout">
        <div class="left-column">
            <div class="card-image-placeholder">
                <img src="images/nets.png" alt="Card Image" class="card-placeholder-image">
            </div>
            <div class="card-display">
                <div class="card-details">
                    <div class="card-lines">
                        <div class="line"></div>
                        <div class="line"></div>
                    </div>
                    <div class="card-chip"></div>
                </div>
                <p class="card-balance">$0.00</p>
            </div>
        </div>

        <div class="button-group">
            <a href="topup.php" class="button top-up">Cash</a>
            <a href="PayMayapay.php" class="button transaction-history">PayMaya</a>
            <a href="Gcashpay.php" class="button vouchers-rewards">Gcash</a>
            <a href="topup.php" class="button vouchers-rewards">Debit/Credit Card</a>
        </div>
    </div>
</div>
<?php include 'footer.php';?>